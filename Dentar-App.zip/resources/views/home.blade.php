<link rel="stylesheet" href="{{ asset('/storage/css/style.css') }}">

