<?php

namespace Database\Seeders;

use App\Models\Doctor;
use App\Models\Patient;
use App\Models\PatientProblem;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class PatientProblemSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {

        $patients = Patient::all();

        foreach($patients as $patient){
            $problem = rand(0, 5);
            $doctor_id = null;

            for($i = 0; $i<$problem; $i++){
                $doctors = Doctor::where('role', 'admin')->get();
                $length = count($doctors);

                for($i = 0; $i< $length; $i++){
                    if($doctors[$i]->nextPatinet){
                        if($i == ($length- 1 )){
                            $doctor_id = $doctors[$i]->id;
                            $doctors[$i]->nextPatinet = false;
                            $doctors[0]->nextPatient = true;
                            $doctors[0]->update();
                            break;
                        }
                        $doctor_id = $doctors[$i]->id;
                        $doctors[$i]->nextPatinet = false;
                        $doctors[++$i]->nextPatient = true;
                        $doctors[$i]->update();
                        break;
                    }


                }
                PatientProblem::factory()->create([
                    'patient_id' => $patient->id,
                    'doctor_id' => 0
                ]);


            }
        }

    }
}
