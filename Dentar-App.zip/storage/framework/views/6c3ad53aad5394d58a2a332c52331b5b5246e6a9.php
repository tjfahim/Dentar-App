<?php $__env->startSection('title'); ?>
Job Manage |
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row mt-4">
    <div class="col-lg-12 grid-margin stretch-card">
        <div class="card">
            <div class="card-body">
                <div class="d-flex justify-content-between">
                    <h4 class="card-title">Job Lists</h4>
                    <div class="d-flex">
                        <button type="button" class="btn btn-outline-info btn-sm btn-icon-text mx-1" onclick="printTable()">
                            <i class="mdi mdi-printer"></i>
                            Print
                        </button>
                        <a href="<?php echo e(route('job.create')); ?>" class="btn btn-sm btn-primary" data-toggle="tooltip" data-placement="right" title="Add Job"><i class="mdi mdi-library-plus"></i> Add Job</a>
                    </div>
                </div>

                <div class="table-responsive pt-3">
                    <div class="company-info text-center">
                        <h1><?php echo e(settings()->website_name); ?></h1>
                        <p class="mt-1"><?php echo e(settings()->address); ?></p>
                        <p class="mt-1"><?php echo e(settings()->website_email); ?></p>
                    </div>

                    <table id="jobTable" class="table table-bordered">
                        <thead>
                            <tr class="text-center bg-info text-dark">
                                <th> # Id</th>
                                <th> Title</th>
                                <th> Description</th>
                                <th> Company</th>
                                <th> Job Deadline</th>
                                <th> Status</th>
                                <th> Action</th>
                            </tr>
                        </thead>

                        <?php if(session('success')): ?>
                            <div class="alert alert-success">
                                <?php echo e(session('success')); ?>

                            </div>
                        <?php endif; ?>

                        <tbody id="jobTableBody">
                            <?php $__empty_1 = true; $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr class="text-center">
                                <td><?php echo e($job->id); ?></td>
                                <td><?php echo e($job->title); ?></td>
                                <td><?php echo e(Str::limit($job->description, 50)); ?></td>
                                <td><?php echo e($job->company_name); ?></td>
                                <td><?php echo e(\Carbon\Carbon::parse($job->job_deadline)->format('d M, Y')); ?></td>
                                <td>
                                    <?php if($job->status == 'active'): ?>
                                        <span style="color: green">Active</span>
                                    <?php else: ?>
                                        <span style="color: red">Inactive</span>
                                    <?php endif; ?>
                                </td>

                                <td class="action d-flex justify-content-center align-items-center">
                                    <a href="<?php echo e(route('job.edit', $job->id)); ?>" class="btn btn-sm btn-info me-2" data-toggle="tooltip" data-placement="right" title="Edit Job"><i class="mdi mdi-grease-pencil"></i></a>

                                    <form action="<?php echo e(route('job.destroy', $job->id)); ?>" method="POST" onsubmit="return confirm('Are you sure you want to delete?')" class="mb-0">
                                        <?php echo method_field('DELETE'); ?>
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="btn btn-sm btn-danger" data-toggle="tooltip" data-placement="right" title="Delete Job">
                                            <i class="mdi mdi-trash-can"></i>
                                        </button>
                                    </form>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr class="text-center">
                                <td colspan="7">No jobs found</td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                    <div class="mt-4 d-flex justify-content-start">
                        <?php echo e($jobs->links('pagination::bootstrap-4')); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\hadiuzzaman\Dentar-App\resources\views/admin/pages/job/index.blade.php ENDPATH**/ ?>