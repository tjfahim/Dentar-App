<?php

namespace App\Http\Controllers\API\V1\Patinet;

use App\Models\PatientProblem;
use App\Http\Controllers\Controller;
use App\Http\Resources\PatientProblemResource;
use App\Models\Doctor;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class PatientProblemController extends Controller
{
    public function problemList()
    {
        $user = Auth::user();

        $cases = $user->cases;

        return PatientProblemResource::collection($cases);
    }


    public function store(Request $request)
    {
        // Validate the incoming request data
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'age' => 'required|integer|min:1|max:120',
            'number' => 'required|string|max:20',
            'image' => 'nullable|image|max:2048', // Optional image with max size 2MB
            'problem' => 'required|string',
        ]);

        // Handle file upload for the image, if provided
        if ($request->hasFile('image')) {
            $validated['image'] = $request->file('image')->store('patient_images', 'public');
        }

        $user = Auth::user();


        $doctor = Doctor::where('role', 'admin')->get();

        return $doctor;

        $attributes = [...$validated, 'patient_id' => $user->id];


        // Add the patient problem record to the database
        $patientProblem = PatientProblem::create($attributes);

        // Return a JSON response
        return response()->json([
            'message' => 'Patient problem added successfully!',
            'data' => $patientProblem,
        ], 201);
    }

}
