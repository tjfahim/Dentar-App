<form action="<?php echo e(route('appSettingManage.userStoreUpdate')); ?>" method="post" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <?php echo method_field('put'); ?>
    <div class="card-body">
        <div class="row">
            <div class="mt-2 col-6">
                <label for="course_passing_percentage">Course Passing Percentage</label>
                <input type="number" name="course_passing_percentage" class="form-control border-info" value="<?php echo e(old('course_passing_percentage', $record->course_passing_percentage ?? '' )); ?>" placeholder="Enter Course Passing Percentage">
                <?php $__errorArgs = ['course_passing_percentage'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="mt-2 col-6">
                <label for="course_quiz_passing_percentage">Course Quiz Passing Percentage</label>
                <input type="number" name="course_quiz_passing_percentage" class="form-control border-info" value="<?php echo e(old('course_quiz_passing_percentage', $record->course_quiz_passing_percentage ?? '')); ?>" placeholder="Enter Course Quiz Passing Percentage">
                <?php $__errorArgs = ['course_quiz_passing_percentage'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="mt-2 col-6">
                <label for="level_passing_percentage">Level Passing Percentage</label>
                <input type="number" name="level_passing_percentage" class="form-control border-info" value="<?php echo e(old('level_passing_percentage', $record->level_passing_percentage ?? '')); ?>" placeholder="Enter Level Passing Percentage">
                <?php $__errorArgs = ['level_passing_percentage'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="mt-2 col-6">
                <label for="course_quiz_limit">Course Quiz Limit</label>
                <input type="number" name="course_quiz_limit" class="form-control border-info" value="<?php echo e(old('course_quiz_limit', $record->course_quiz_limit ?? '')); ?>" placeholder="Enter Course Quiz Limit">
                <?php $__errorArgs = ['course_quiz_limit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="mt-2 col-6">
                <label for="level_quiz_limit">Level Quiz Limit</label>
                <input type="number" name="level_quiz_limit" class="form-control border-info" value="<?php echo e(old('level_quiz_limit', $record->level_quiz_limit ?? '')); ?>" placeholder="Enter Level Quiz Limit">
                <?php $__errorArgs = ['level_quiz_limit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="d-flex justify-content-end mt-4">
                <button type="submit" class="btn btn-sm btn-success"><i class="mdi mdi-content-save"></i> Save</button>
            </div>
        </div>
    </div>
</form>
<?php /**PATH /home/redail/public_html/game.redsmail.xyz/resources/views/admin/pages/setting_manages/partials/_user.blade.php ENDPATH**/ ?>