

<?php $__env->startSection('title'); ?>
    Edit Subscription |
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row mt-4 d-flex justify-content-center">
    <div class="col-lg-6 grid-margin stretch-card">
        <div class="card">
            <form action="<?php echo e(route('subscription.update', $subscription->id)); ?>" method="post" enctype="multipart/form-data">
                <?php echo method_field('put'); ?>
                <?php echo csrf_field(); ?>
                <?php if($errors->any()): ?>
                    <div class="alert alert-danger" role="alert">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <h4 class="card-title">Edit Subscription</h4>
                        <a href="<?php echo e(route('subscription.index')); ?>" class="btn btn-sm btn-primary" data-toggle="tooltip" data-placement="right" title="List Subscriptions">
                            <i class="mdi mdi-step-backward"></i> List Subscriptions
                        </a>
                    </div>
                    <div class="row mt-5">

                        <input type="hidden" id="user_id" name="user_id" value="<?php echo e($subscription->user_id); ?>">
                        <input type="hidden" id="in_app_item_id" name="in_app_item_id" value="<?php echo e($subscription->in_app_item_id); ?>">
                        <!-- User Name -->
                        <div class="mt-2">
                            <label for="user_name">User Name</label>
                            <input type="text" name="user_name" class="form-control border-info" value="<?php echo e(old('user_name', $subscription->user->name)); ?>" placeholder="Enter User Name" disabled>
                            <?php $__errorArgs = ['user_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Item -->
                        <div class="mt-2">
                            <label for="item_name">Item</label>
                            <input type="text" name="item_name" class="form-control border-info" value="<?php echo e(old('item_name', $subscription->inAppItem->name)); ?>" placeholder="Enter User Name" disabled>

                            <?php $__errorArgs = ['item'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Quantity -->
                        <div class="mt-2">
                            <label for="quantity">Quantity</label>
                            <input type="number" name="quantity" class="form-control border-info" value="<?php echo e(old('quantity', $subscription->quantity)); ?>" placeholder="Enter Quantity" required>
                            <?php $__errorArgs = ['quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Paid Amount -->
                        <div class="mt-2">
                            <label for="paid_amount">Paid Amount</label>
                            <input type="number" step="0.01" name="paid_amount" class="form-control border-info" value="<?php echo e(old('paid_amount', $subscription->paid_amount)); ?>" placeholder="Enter Paid Amount" required>
                            <?php $__errorArgs = ['paid_amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Payment Status -->
                        <div class="mt-2">
                            <label for="payment_status">Payment Status</label>
                            <select name="payment_status" class="form-control border-info" required>
                                <option value="pending" <?php echo e(old('payment_status', $subscription->payment_status) == 'pending' ? 'selected' : ''); ?>>Pending</option>
                                <option value="completed" <?php echo e(old('payment_status', $subscription->payment_status) == 'completed' ? 'selected' : ''); ?>>Completed</option>
                                <option value="failed" <?php echo e(old('payment_status', $subscription->payment_status) == 'failed' ? 'selected' : ''); ?>>Failed</option>
                                
                            </select>
                            <?php $__errorArgs = ['payment_status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Payment Method -->
                        <div class="mt-2">
                            <label for="payment_method">Payment Method</label>
                            <input type="text" name="payment_method" class="form-control border-info" value="<?php echo e(old('payment_method', $subscription->payment_method)); ?>" placeholder="Enter Payment Method">
                            <?php $__errorArgs = ['payment_method'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Transaction ID -->
                        <div class="mt-2">
                            <label for="transaction_id">Transaction ID</label>
                            <input type="text" name="transaction_id" class="form-control border-info" value="<?php echo e(old('transaction_id', $subscription->transaction_id)); ?>" placeholder="Enter Transaction ID">
                            <?php $__errorArgs = ['transaction_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Submit Button -->
                        <div class="d-flex justify-content-end mt-2">
                            <button type="submit" class="btn btn-sm btn-info"><i class="mdi mdi-content-save"></i> Update Subscription</button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/redail/public_html/game.redsmail.xyz/resources/views/admin/pages/subscriptions/edit.blade.php ENDPATH**/ ?>