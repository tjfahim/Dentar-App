

<?php $__env->startSection('title'); ?>
    Edit App Settings |
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row mt-4 d-flex justify-content-center">
    <div class="col-lg-6 grid-margin stretch-card">
        <div class="card">
            <form action="<?php echo e(route('appSettingManage.update')); ?>" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?> 
 <?php echo method_field('put'); ?>

                <?php if(session('success')): ?>
                    <div class="alert alert-success" role="alert">
                        <?php echo e(session('success')); ?>

                    </div>
                <?php endif; ?>

                <?php if($errors->any()): ?>
                    <div class="alert alert-danger" role="alert">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <h4 class="card-title">Edit App Settings</h4>
                        <a href="<?php echo e(route('appSettingManage.edit')); ?>" class="btn btn-sm btn-primary" data-toggle="tooltip" data-placement="right" title="Back to Settings"><i class="mdi mdi-step-backward"></i> Back to Settings</a>
                    </div>
                    <div class="row mt-5">
                        <div class="mt-2">
                            <label for="title">Title</label>
                            <input type="text" name="title" class="form-control border-info" value="<?php echo e(old('title', $record->title)); ?>" placeholder="Enter Title">
                            <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mt-2">
                            <label for="description">Description</label>
                            <textarea name="description" class="form-control border-info" placeholder="Enter Description"><?php echo e(old('description', $record->description)); ?></textarea>
                            <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mt-2">
                            <label for="phoneimage">Phone Image</label>
                            <input type="file" name="phoneimage" class="form-control border-info">
                            <?php $__errorArgs = ['phoneimage'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <?php if($record->phoneimage): ?>
                        <div class="mt-2">
                            <label>Current Phone Image</label>
                            <img src="<?php echo e(asset('storage/' . $record->phoneimage)); ?>" alt="Current Phone Image" style="width: 150px; height: auto;">
                        </div>
                        <?php endif; ?>
                        <div class="mt-2">
                            <label for="phonenumber">Phone Number</label>
                            <input type="text" name="phonenumber" class="form-control border-info" value="<?php echo e(old('phonenumber', $record->phonenumber)); ?>" placeholder="Enter Phone Number">
                            <?php $__errorArgs = ['phonenumber'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mt-2">
                            <label for="emailimage">Email Image</label>
                            <input type="file" name="emailimage" class="form-control border-info">
                            <?php $__errorArgs = ['emailimage'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <?php if($record->emailimage): ?>
                        <div class="mt-2">
                            <label>Current Email Image</label>
                            <img src="<?php echo e(asset('storage/' . $record->emailimage)); ?>" alt="Current Email Image" style="width: 150px; height: auto;">
                        </div>
                        <?php endif; ?>
                        <div class="mt-2">
                            <label for="email">Email</label>
                            <input type="email" name="email" class="form-control border-info" value="<?php echo e(old('email', $record->email)); ?>" placeholder="Enter Email">
                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mt-2">
                            <label for="locationimage">Location Image</label>
                            <input type="file" name="locationimage" class="form-control border-info">
                            <?php $__errorArgs = ['locationimage'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <?php if($record->locationimage): ?>
                        <div class="mt-2">
                            <label>Current Location Image</label>
                            <img src="<?php echo e(asset('storage/' . $record->locationimage)); ?>" alt="Current Location Image" style="width: 150px; height: auto;">
                        </div>
                        <?php endif; ?>
                        <div class="mt-2">
                            <label for="location">Location</label>
                            <input type="text" name="location" class="form-control border-info" value="<?php echo e(old('location', $record->location)); ?>" placeholder="Enter Location">
                            <?php $__errorArgs = ['location'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mt-2">
                            <label for="policy1title">Policy 1 Title</label>
                            <input type="text" name="policy1title" class="form-control border-info" value="<?php echo e(old('policy1title', $record->policy1title)); ?>" placeholder="Enter Policy 1 Title">
                            <?php $__errorArgs = ['policy1title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mt-2">
                            <label for="policy1description">Policy 1 Description</label>
                            <textarea name="policy1description" class="form-control border-info" placeholder="Enter Policy 1 Description"><?php echo e(old('policy1description', $record->policy1description)); ?></textarea>
                            <?php $__errorArgs = ['policy1description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mt-2">
                            <label for="policy2title">Policy 2 Title</label>
                            <input type="text" name="policy2title" class="form-control border-info" value="<?php echo e(old('policy2title', $record->policy2title)); ?>" placeholder="Enter Policy 2 Title">
                            <?php $__errorArgs = ['policy2title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mt-2">
                            <label for="policy2description">Policy 2 Description</label>
                            <textarea name="policy2description" class="form-control border-info" placeholder="Enter Policy 2 Description"><?php echo e(old('policy2description', $record->policy2description)); ?></textarea>
                            <?php $__errorArgs = ['policy2description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="d-flex justify-content-end mt-2">
                            <button type="submit" class="btn btn-sm btn-info"><i class="mdi mdi-content-save"></i> Update</button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\roopi\resources\views/admin/pages/app_settings/edit.blade.php ENDPATH**/ ?>