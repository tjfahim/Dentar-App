
<?php $__env->startSection('title'); ?>
Dashboard |
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class=" mt-2">
	<div id="dashboard_patient_found">
		<div class="card">
			<div class="card-body pb-0">
				<div class="dashboard-search-field">
					<input type="text" id="dashboard_search" name="dashboard_search" class="form-control" placeholder="Mobile">
					<button id="search_button" class="btn btn-secondary">Search</button>
				</div>
				<div class="align-items-center justify-content-between">

				</div>
			</div>
		</div>
	</div>

    <div class="row row-cols-6">

		<?php $__currentLoopData = [
		// ['url' => route('courseGoal.index'), 'count' => $courseGoalManageCount, 'title' => 'Course Goal'],
		// ['url' => route('courseManages.index'), 'count' => $courseManageCount, 'title' => 'Courses'],
		// ['url' => route('booksManage.index'), 'count' => $booksManageCount, 'title' => 'Books'],
		// ['url' => route('chapterManage.index'), 'count' => $chapterManageCount, 'title' => 'Chapters'],
		// ['url' => route('mentorManage.index'), 'count' => $mentorManageCount, 'title' => 'Mentors'],
		// ['url' => route('moduleManage.index'), 'count' => $moduleManageCount, 'title' => 'Modules'],
		// ['url' => route('videoManage.index'), 'count' => $videoManageCount, 'title' => 'Videos'],
		// ['url' => route('pdfManage.index'), 'count' => $pdfManageCount, 'title' => 'PDF'],
		['url' => '', 'count' => $usersCount, 'title' => 'Users'],
		]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<div class="col-md-2 mb-4">
			<a href="<?php echo e($item['url']); ?>" class="d-block text-decoration-none">
				<div class="card d-flex flex-column">
					<div class="card-body pb-0">
						<div class="d-flex align-items-center justify-content-between">
							<h2 class="text-danger font-weight-bold"><?php echo e($item['count']); ?></h2>
							<i class="mdi mdi-account-outline mdi-18px text-dark"></i>
						</div>
					</div>
					<canvas id="allProducts"></canvas>
					<div class="line-chart-row-title"><?php echo e($item['title']); ?></div>
				</div>
			</a>
		</div>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

	</div>


</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\roopi\resources\views/admin/pages/dashboard.blade.php ENDPATH**/ ?>