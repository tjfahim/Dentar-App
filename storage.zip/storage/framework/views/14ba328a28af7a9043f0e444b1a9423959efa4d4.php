

<?php $__env->startSection('title'); ?>
    Edit Withdrawal |
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row mt-4 d-flex justify-content-center">
    <div class="col-lg-6 grid-margin stretch-card">
        <div class="card">
            <form action="<?php echo e(route('withdraw.update', $withdrawal->id)); ?>" method="post" enctype="multipart/form-data">
                <?php echo method_field('put'); ?>
                <?php echo csrf_field(); ?>
                <?php if($errors->any()): ?>
                    <div class="alert alert-danger" role="alert">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <h4 class="card-title">Edit Withdrawal</h4>
                        <a href="<?php echo e(route('withdraw.index')); ?>" class="btn btn-sm btn-primary" data-toggle="tooltip" data-placement="right" title="List Withdrawals">
                            <i class="mdi mdi-step-backward"></i> List Withdrawals
                        </a>
                    </div>
                    <div class="row mt-5">

                        <!-- Hidden Fields -->
                        <input type="hidden" id="user_id" name="user_id" value="<?php echo e($withdrawal->user_id); ?>">

                        <!-- User Name -->
                        <div class="mt-2">
                            <label for="user_name">User Name</label>
                            <input type="text" name="user_name" class="form-control border-info" value="<?php echo e(old('user_name', $withdrawal->user->name)); ?>" placeholder="Enter User Name" disabled>
                            <?php $__errorArgs = ['user_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- User Account Name -->
                        <div class="mt-2">
                            <label for="user_account_name">Account Name</label>
                            <input type="text" name="user_account_name" class="form-control border-info" value="<?php echo e(old('user_account_name', $withdrawal->user_account_name)); ?>" placeholder="Enter Account Name" disabled>
                            <?php $__errorArgs = ['user_account_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Account Number -->
                        <div class="mt-2">
                            <label for="account_number">Account Number</label>
                            <input type="text" name="account_number" class="form-control border-info" value="<?php echo e(old('account_number', $withdrawal->account_number)); ?>" placeholder="Enter Account Number" disabled>
                            <?php $__errorArgs = ['account_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Total Diamond -->
                        <div class="mt-2">
                            <label for="total_diamond">Total Diamonds</label>
                            <input type="number" name="total_diamond" class="form-control border-info" value="<?php echo e(old('total_diamond', $withdrawal->total_diamond)); ?>" placeholder="Enter Total Diamonds" disabled>
                            <?php $__errorArgs = ['total_diamond'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Payment Amount -->
                        <div class="mt-2">
                            <label for="pay_amount">Payment Amount</label>
                            <input type="number" step="0.01" name="pay_amount" class="form-control border-info" value="<?php echo e(old('pay_amount', $withdrawal->pay_amount)); ?>" placeholder="Enter Payment Amount" >
                            <?php $__errorArgs = ['pay_amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Payment Method -->
                        <div class="mt-2">
                            <label for="pay_method">Payment Method</label>
                            <input type="text" name="pay_method" class="form-control border-info" value="<?php echo e(old('pay_method', $withdrawal->pay_method)); ?>" placeholder="Enter Payment Method" >
                            <?php $__errorArgs = ['pay_method'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Status -->
                        <div class="mt-2">
                            <label for="status">Status</label>
                            <select name="status" class="form-control border-info" required>
                                <option value="pending" <?php echo e(old('status', $withdrawal->status) == 'pending' ? 'selected' : ''); ?>>Pending</option>
                                <option value="approved" <?php echo e(old('status', $withdrawal->status) == 'approved' ? 'selected' : ''); ?>>Approved</option>
                                <option value="rejected" <?php echo e(old('status', $withdrawal->status) == 'rejected' ? 'selected' : ''); ?>>Rejected</option>
                            </select>
                            <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Reply Message -->
                        <div class="mt-2">
                            <label for="reply_message">Reply Message</label>
                            <textarea name="reply_message" class="form-control border-info" rows="3" placeholder="Enter Reply Message"><?php echo e(old('reply_message', $withdrawal->reply_message)); ?></textarea>
                            <?php $__errorArgs = ['reply_message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Submit Button -->
                        <div class="d-flex justify-content-end mt-2">
                            <button type="submit" class="btn btn-sm btn-info"><i class="mdi mdi-content-save"></i> Update Withdrawal</button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\roopi\resources\views/admin/pages/withdrawals/edit.blade.php ENDPATH**/ ?>