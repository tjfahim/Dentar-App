<footer class="footer">
    <div class="footer-wrap">
      <div class="d-sm-flex justify-content-center justify-content-sm-center">
        <span class="text-muted text-center text-sm-left d-block d-sm-inline-block">Copyright © <?php echo e(date('Y')); ?></a> - 2030</span>
      </div>
    </div>
  </footer><?php /**PATH C:\xampp\htdocs\roopi\resources\views/admin/layouts/footer.blade.php ENDPATH**/ ?>