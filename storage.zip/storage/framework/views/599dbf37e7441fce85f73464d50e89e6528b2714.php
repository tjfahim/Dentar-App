

<?php $__env->startSection('title'); ?>
    Setting | Admin Panel
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row mt-4 d-flex justify-content-center">
    <div class="col-md-12 grid-margin stretch-card">
        <div class="card">

            
            <?php if(session('success')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>

            
            <?php if(session('error')): ?>
                <div class="alert alert-danger">
                    <?php echo e(session('error')); ?>

                </div>
            <?php endif; ?>

            <?php if($errors->any()): ?>
                <div class="alert alert-danger" role="alert">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            <ul class="nav nav-tabs d-flex justify-content-center" id="myTab" role="tablist">
                <li class="nav-item" role="presentation">
                    <button class="nav-link" id="app-tab" data-bs-toggle="tab" data-bs-target="#app-tab-pane"
                        type="button" role="tab" aria-controls="app-tab-pane" aria-selected="true">App Setting</button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link" id="web-tab" data-bs-toggle="tab" data-bs-target="#web-tab-pane"
                        type="button" role="tab" aria-controls="web-tab-pane" aria-selected="true">Web Setting</button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link" id="user-tab" data-bs-toggle="tab" data-bs-target="#user-tab-pane"
                        type="button" role="tab" aria-controls="user-tab-pane" aria-selected="true">Web Setting</button>
                </li>
            </ul>

            <div class="tab-content" id="myTabContent">
                <div class="tab-pane fade" id="app-tab-pane" role="tabpanel" aria-labelledby="app-tab">
                    <?php echo $__env->make('admin.pages.setting_manages.partials._app', ['record' => $appSettingManage], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="tab-pane fade" id="web-tab-pane" role="tabpanel" aria-labelledby="web-tab">
                    <?php echo $__env->make('admin.pages.setting_manages.partials._web', ['record' => $webSettingManage], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="tab-pane fade" id="user-tab-pane" role="tabpanel" aria-labelledby="user-tab">
                    <?php echo $__env->make('admin.pages.setting_manages.partials._user', ['record' => $userSetting], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<script>
    document.addEventListener('DOMContentLoaded', function () {
      // Get the tab from the URL query parameter
      let tab = new URLSearchParams(window.location.search).get('tab');

      // Check if a tab is specified
      if (tab) {
          // Find the corresponding tab button
          let targetTabButton = document.querySelector(`#${tab}`);
          let targetTabPane = document.querySelector(`#${tab}-pane`);

          if (targetTabButton && targetTabPane) {
              // Remove 'active' class from all tab buttons and panes
              document.querySelectorAll('.nav-link').forEach(button => button.classList.remove('active'));
              document.querySelectorAll('.tab-pane').forEach(pane => pane.classList.remove('show', 'active'));

              // Activate the target tab and pane
              targetTabButton.classList.add('active');
              targetTabPane.classList.add('show', 'active');
          }
      } else {
          let defaultTabButton = document.querySelector('#app-tab');
          let defaultTabPane = document.querySelector('#app-tab-pane');

          if (defaultTabButton && defaultTabPane) {
              defaultTabButton.classList.add('active');
              defaultTabPane.classList.add('show', 'active');
          }
      }
    });
</script>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/redail/public_html/game.redsmail.xyz/resources/views/admin/pages/setting_manages/index.blade.php ENDPATH**/ ?>