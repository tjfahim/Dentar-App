<form action="<?php echo e(route('appSettingManage.update')); ?>" method="post" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
<?php echo method_field('put'); ?>


    <div class="card-body">

        <div class="row">
            <div class="mt-2">
                <label for="title">Title</label>
                <input type="text" name="title" class="form-control border-info" value="<?php echo e(old('title', $record->title)); ?>" placeholder="Enter Title">
                <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="mt-2">
                <label for="description">Description</label>
                <textarea name="description" class="form-control border-info" placeholder="Enter Description"><?php echo e(old('description', $record->description)); ?></textarea>
                <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="mt-2">
                <label for="phoneimage">Phone Image</label>
                <input type="file" name="phoneimage" class="form-control border-info">
                <?php $__errorArgs = ['phoneimage'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <?php if($record->phoneimage): ?>
            <div class="mt-2">
                <label>Current Phone Image</label>
                <img src="<?php echo e(asset('storage/' . $record->phoneimage)); ?>" alt="Current Phone Image" style="width: 150px; height: auto;">
            </div>
            <?php endif; ?>
            <div class="mt-2">
                <label for="phonenumber">Phone Number</label>
                <input type="text" name="phonenumber" class="form-control border-info" value="<?php echo e(old('phonenumber', $record->phonenumber)); ?>" placeholder="Enter Phone Number">
                <?php $__errorArgs = ['phonenumber'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="mt-2">
                <label for="emailimage">Email Image</label>
                <input type="file" name="emailimage" class="form-control border-info">
                <?php $__errorArgs = ['emailimage'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <?php if($record->emailimage): ?>
            <div class="mt-2">
                <label>Current Email Image</label>
                <img src="<?php echo e(asset('storage/' . $record->emailimage)); ?>" alt="Current Email Image" style="width: 150px; height: auto;">
            </div>
            <?php endif; ?>
            <div class="mt-2">
                <label for="email">Email</label>
                <input type="email" name="email" class="form-control border-info" value="<?php echo e(old('email', $record->email)); ?>" placeholder="Enter Email">
                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="mt-2">
                <label for="locationimage">Location Image</label>
                <input type="file" name="locationimage" class="form-control border-info">
                <?php $__errorArgs = ['locationimage'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <?php if($record->locationimage): ?>
            <div class="mt-2">
                <label>Current Location Image</label>
                <img src="<?php echo e(asset('storage/' . $record->locationimage)); ?>" alt="Current Location Image" style="width: 150px; height: auto;">
            </div>
            <?php endif; ?>
            <div class="mt-2">
                <label for="location">Location</label>
                <input type="text" name="location" class="form-control border-info" value="<?php echo e(old('location', $record->location)); ?>" placeholder="Enter Location">
                <?php $__errorArgs = ['location'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="mt-2">
                <label for="policy1title">Policy 1 Title</label>
                <input type="text" name="policy1title" class="form-control border-info" value="<?php echo e(old('policy1title', $record->policy1title)); ?>" placeholder="Enter Policy 1 Title">
                <?php $__errorArgs = ['policy1title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="mt-2">
                <label for="policy1description">Policy 1 Description</label>
                <textarea name="policy1description" class="form-control border-info" placeholder="Enter Policy 1 Description"><?php echo e(old('policy1description', $record->policy1description)); ?></textarea>
                <?php $__errorArgs = ['policy1description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="mt-2">
                <label for="policy2title">Policy 2 Title</label>
                <input type="text" name="policy2title" class="form-control border-info" value="<?php echo e(old('policy2title', $record->policy2title)); ?>" placeholder="Enter Policy 2 Title">
                <?php $__errorArgs = ['policy2title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="mt-2">
                <label for="policy2description">Policy 2 Description</label>
                <textarea name="policy2description" class="form-control border-info" placeholder="Enter Policy 2 Description"><?php echo e(old('policy2description', $record->policy2description)); ?></textarea>
                <?php $__errorArgs = ['policy2description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="d-flex justify-content-end mt-2">
                <button type="submit" class="btn btn-sm btn-info"><i class="mdi mdi-content-save"></i> Update</button>
            </div>
        </div>
    </div>
</form>
<?php /**PATH /home/redail/public_html/game.redsmail.xyz/resources/views/admin/pages/setting_manages/partials/_app.blade.php ENDPATH**/ ?>