

<?php $__env->startSection('title'); ?>
    Subscription |
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row mt-4">
    <div class="col-lg-12 grid-margin stretch-card">
        <div class="card">
            <div class="card-body">
                <div class="d-flex justify-content-between">
                    <h4 class="card-title">Subscription List</h4>
                    <button type="button" class="btn btn-outline-info btn-sm btn-icon-text mx-1" onclick="printTable()">
                        <i class="mdi mdi-printer"></i>
                        Print
                    </button>
                    
                </div>
                <div class="table-responsive pt-3">
                    <table id="courseReportManageTable" class="table table-bordered">
                        <thead>
                            <tr class="text-center bg-info text-dark">
                                <th># Id</th>
                                <th>User Name</th>
                                <th>Item</th>
                                <th>Quantity</th>
                                <th>Paid Amount</th>
                                <th>Payment Status</th>
                                <th>Payment Method</th>
                                <th>Transaction ID</th>
                                <th>Date</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <?php if(session('success')): ?>
                            <div class="alert alert-success">
                                <?php echo e(session('success')); ?>

                            </div>
                        <?php endif; ?>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $subscriptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subscription): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr class="text-center">
                                <td><?php echo e($subscription->id ?? ''); ?></td>
                                <td><?php echo e($subscription->user->name ?? ''); ?></td>
                                <td><?php echo e($subscription->inAppItem->name ?? ''); ?></td>
                                <td><?php echo e($subscription->quantity ?? ''); ?></td>
                                <td><?php echo e($subscription->paid_amount ?? ''); ?></td>
                                <td><?php echo e($subscription->payment_status ?? ''); ?></td>
                                <td><?php echo e($subscription->payment_method ?? ''); ?></td>
                                <td><?php echo e($subscription->transaction_id ?? ''); ?></td>
                                <td><?php echo e($subscription->created_at->format('j F Y, g:i a') ?? ''); ?></td>
                                <td>
                                    <a href="<?php echo e(route('subscription.edit', $subscription->id)); ?>" class="btn btn-sm btn-info me-2" data-toggle="tooltip" data-placement="right" title="Edit Item"><i class="mdi mdi-grease-pencil"></i></a>
                                </td>

                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr class="text-center">
                                <td colspan="8">No data found</td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/redail/public_html/game.redsmail.xyz/resources/views/admin/pages/subscriptions/index.blade.php ENDPATH**/ ?>