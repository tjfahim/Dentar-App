

<?php $__env->startSection('title'); ?>
    Withdrawals |
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row mt-4">
    <div class="col-lg-12 grid-margin stretch-card">
        <div class="card">
            <div class="card-body">
                <div class="d-flex justify-content-between">
                    <h4 class="card-title">Withdrawal List</h4>
                    <button type="button" class="btn btn-outline-info btn-sm btn-icon-text mx-1" onclick="printTable()">
                        <i class="mdi mdi-printer"></i>
                        Print
                    </button>
                </div>
                <div class="table-responsive pt-3">
                    <table id="withdrawalManageTable" class="table table-bordered">
                        <thead>
                            <tr class="text-center bg-info text-dark">
                                <th># Id</th>
                                <th>User Name</th>
                                <th>Account Name</th>
                                <th>Account Number</th>
                                <th>Total Diamonds</th>
                                <th>Pay Amount</th>
                                <th>Pay Method</th>
                                <th>Status</th>
                                <th>Reply Message</th>
                                <th>Date</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <?php if(session('success')): ?>
                            <div class="alert alert-success">
                                <?php echo e(session('success')); ?>

                            </div>
                        <?php endif; ?>
                        <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $withdrawals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $withdrawal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr class="text-center">
                                <td><?php echo e($withdrawal->id ?? ''); ?></td>
                                <td><?php echo e($withdrawal->user->name ?? ''); ?></td>
                                <td><?php echo e($withdrawal->user_account_name ?? ''); ?></td>
                                <td><?php echo e($withdrawal->account_number ?? ''); ?></td>
                                <td><?php echo e($withdrawal->total_diamond ?? ''); ?></td>
                                <td><?php echo e($withdrawal->pay_amount ?? ''); ?></td>
                                <td><?php echo e($withdrawal->pay_method ?? ''); ?></td>
                                <td class="<?php echo e($withdrawal->status == 'approved' ? 'text-success' : ($withdrawal->status == 'rejected' ? 'text-danger' : '')); ?>">
                                    <?php echo e(ucfirst($withdrawal->status) ?? ''); ?>

                                </td>
                                <td><?php echo e($withdrawal->reply_message ?? 'N/A'); ?></td>
                                <td><?php echo e($withdrawal->created_at->format('j F Y, g:i a') ?? ''); ?></td>
                                <td>
                                    <?php if($withdrawal->status == 'pending'): ?>
                                        <a href="<?php echo e(route('withdraw.edit', $withdrawal->id)); ?>" class="btn btn-sm btn-info me-2" data-toggle="tooltip" data-placement="right" title="Edit Withdrawal"><i class="mdi mdi-grease-pencil"></i></a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr class="text-center">
                                <td colspan="11">No data found</td>
                            </tr>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\roopi\resources\views/admin/pages/withdrawals/index.blade.php ENDPATH**/ ?>