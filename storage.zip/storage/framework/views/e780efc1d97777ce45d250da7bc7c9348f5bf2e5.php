<div class="horizontal-menu">
    <nav class="navbar top-navbar col-lg-12 col-12 p-0">
        <div class="container-fluid">
            <div class="navbar-menu-wrapper d-flex align-items-center justify-content-between">
                <div class="text-center navbar-brand-wrapper d-flex align-items-center justify-content-center">
                    <a class="navbar-brand brand-logo" href="<?php echo e(url('/')); ?>">
                        <img src="<?php echo e(asset('/storage/admin')); ?>/<?php echo e(settings()->website_logo); ?>" style="width:70px;height:70px;" alt="logo" />
                    </a>
                    <a class="navbar-brand brand-logo-mini" href="<?php echo e(url('/')); ?>">
                        <img src="<?php echo e(asset('/storage/admin')); ?>/<?php echo e(settings()->website_logo); ?>" style="width:70px;height:70px;" alt="logo" />
                    </a>
                </div>
                <ul class="navbar-nav navbar-nav-right">
                    <li class="nav-item text-dark text-capitalize">
                        <h3>Welcome <?php echo e(Auth::user()->designation); ?> dashboard</h3>
                    </li>
                    <li class="nav-item dropdown d-lg-flex d-none">
                        <a href="<?php echo e(route('user.settings', Auth::user()->id)); ?>" class="btn btn-inverse-primary btn-sm">Settings</a>
                    </li>
                    <li class="nav-item nav-profile dropdown">
                        <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown" id="profileDropdown">
                            <span class="nav-profile-name"><?php echo e(Auth::user()->name); ?></span>
                            <span class="online-status"></span>
                        </a>
                        <div class="dropdown-menu dropdown-menu-right navbar-dropdown" aria-labelledby="profileDropdown">
                            <a href="<?php echo e(route('user.settings', Auth::user()->id)); ?>" class="dropdown-item">
                                <i class="mdi mdi-settings text-primary"></i>
                                My Profile
                            </a>
                            <a href="<?php echo e(route('user.settingsChangeUserPassword', Auth::user()->id)); ?>" class="dropdown-item">
                                <i class="mdi mdi-settings text-primary"></i>
                                Change Password
                            </a>
                            <a class="dropdown-item" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                                <i class="mdi mdi-logout text-primary"></i>
                                Logout
                            </a>
                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                <?php echo csrf_field(); ?>
                            </form>
                        </div>
                    </li>
                </ul>
                <button class="navbar-toggler navbar-toggler-right d-lg-none align-self-center" type="button" data-toggle="horizontal-menu-toggle">
                    <span class="mdi mdi-menu"></span>
                </button>
            </div>
        </div>
    </nav>

    <nav class="bottom-navbar">
        <div class="container">
            <ul class="nav page-navigation">
                <!-- Dashboard Menu Item -->
                <li class="nav-item <?php echo e(Request::is('dashboard') ? 'active' : ''); ?>">
                    <a class="nav-link" href="<?php echo e(url('dashboard')); ?>">
                        <i class="mdi mdi-file-document-box menu-icon"></i>
                        <span class="menu-title">Dashboard</span>
                    </a>
                </li>

                <!-- User Manage Menu Item -->
                <li class="nav-item <?php echo e(Request::is('users') || Request::is('users/*') ? 'active' : ''); ?>">
                    <a href="#" class="nav-link">
                        <i class="mdi mdi-chart-areaspline menu-icon"></i>
                        <span class="menu-title">User Manage</span>
                        <i class="menu-arrow"></i>
                    </a>
                    <div class="submenu">
                        <ul>
                            <li class="nav-item"><a class="nav-link" href="<?php echo e(url('users')); ?>">User Manage</a></li>
                        </ul>
                    </div>
                </li>

                <!-- Subscription Menu Item -->
                <li class="nav-item <?php echo e(Request::is('items') || Request::is('items/*') || Request::is('subscriptions') || Request::is('subscriptions/*') ? 'active' : ''); ?>">
                    <a href="#" class="nav-link">
                        <i class="mdi mdi-chart-areaspline menu-icon"></i>
                        <span class="menu-title">Subscription</span>
                        <i class="menu-arrow"></i>
                    </a>
                    <div class="submenu">
                        <ul>
                            <li class="nav-item"><a class="nav-link" href="<?php echo e(url('items')); ?>">Items Manage</a></li>
                            <li class="nav-item"><a class="nav-link" href="<?php echo e(url('subscription')); ?>">Subscriptions Manage</a></li>
                            <li class="nav-item"><a class="nav-link" href="<?php echo e(url('withdraw')); ?>">Withdraw Manage</a></li>
                        </ul>
                    </div>
                </li>

                <!-- Message Menu Item -->
                <li class="nav-item <?php echo e(Request::is('rooms') || Request::is('rooms/*') || Request::is('messages') || Request::is('messages/*') ? 'active' : ''); ?>">
                    <a href="#" class="nav-link">
                        <i class="mdi mdi-chart-areaspline menu-icon"></i>
                        <span class="menu-title">Message</span>
                        <i class="menu-arrow"></i>
                    </a>
                    <div class="submenu">
                        <ul>
                            <li class="nav-item"><a class="nav-link" href="<?php echo e(url('rooms')); ?>">Rooms Manage</a></li>
                            <li class="nav-item"><a class="nav-link" href="<?php echo e(url('messages')); ?>">Messages Manage</a></li>
                        </ul>
                    </div>
                </li>

                <!-- Setting Menu Item -->
                <li class="nav-item <?php echo e(Request::is('settings') || Request::is('user/settings/*') ? 'active' : ''); ?>">
                    <a href="#" class="nav-link">
                        <i class="mdi mdi-chart-areaspline menu-icon"></i>
                        <span class="menu-title">Setting</span>
                        <i class="menu-arrow"></i>
                    </a>
                    <div class="submenu">
                        <ul>
                            <li class="nav-item"><a class="nav-link" href="<?php echo e(url('settings')); ?>">Settings</a></li>
                            <li class="nav-item"><a class="nav-link" href="<?php echo e(url('user/settings/' . Auth::user()->id)); ?>">Profile Settings</a></li>
                        </ul>
                    </div>
                </li>
            </ul>
        </div>
    </nav>
</div>
<?php /**PATH C:\xampp\htdocs\roopi\resources\views/admin/layouts/header.blade.php ENDPATH**/ ?>